import React from 'react';
import {Easing, interpolate, staticFile} from 'remotion';
import {D, bounds, centroid, P, arcPts, line} from './geo';
import {Cam} from './camera';

const ACCENT = '#ffd166';
const clamp = (v: number) => Math.min(1, Math.max(0, v));
const prog = (s: number, a: number, b: number) => Easing.bezier(0.4, 0, 0.2, 1)(clamp((s - a) / (b - a)));

type Region = 'alaska' | 'lower48' | 'russia';

const Flag: React.FC<{region: Region; d: string; flag: 'us' | 'ru'; from: number; to: number; sec: number; origin: [number, number]; id: string}> = ({region, d, flag, from, to, sec, origin, id}) => {
  const u = prog(sec, from, to);
  if (u <= 0) return null;
  const [[x0, y0], [x1, y1]] = (bounds as any)[region];
  const R = Math.hypot(x1 - x0, y1 - y0) * 1.1;
  return (
    <g>
      <clipPath id={`c-${id}`}><path d={d} /></clipPath>
      <clipPath id={`r-${id}`}><circle cx={origin[0]} cy={origin[1]} r={R * u} /></clipPath>
      <g clipPath={`url(#c-${id})`}>
        <g clipPath={`url(#r-${id})`}>
          <image href={staticFile(`flags/${flag}.svg`)} x={x0} y={y0} width={x1 - x0} height={y1 - y0} preserveAspectRatio="xMidYMid slice" opacity={0.9} />
        </g>
      </g>
    </g>
  );
};

const Outline: React.FC<{d: string; z: number; draw: number; w?: number; color?: string}> = ({d, z, draw, w = 2.4, color = '#fff'}) => {
  if (draw <= 0) return null;
  return (
    <g fill="none" strokeLinejoin="round" strokeLinecap="round">
      <path d={d} stroke={color} strokeOpacity={0.22 * draw} strokeWidth={(w * 3.2) / z} />
      <path d={d} stroke={color} strokeWidth={w / z} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} />
    </g>
  );
};

const Marker: React.FC<{p: [number, number]; z: number; sec: number; at: number}> = ({p, z, sec, at}) => {
  const u = prog(sec, at, at + 0.35);
  if (u <= 0) return null;
  const pulse = ((sec - at) * 0.9) % 1;
  return (
    <g transform={`translate(${p[0]},${p[1]})`}>
      <circle r={(10 + pulse * 34) / z} fill="none" stroke={ACCENT} strokeOpacity={(1 - pulse) * 0.8} strokeWidth={2 / z} />
      <circle r={(9 * u) / z} fill={ACCENT} stroke="#1a1200" strokeWidth={2 / z} />
    </g>
  );
};

export const MapLayer: React.FC<{sec: number; cam: Cam}> = ({sec, cam}) => {
  const z = cam.z;
  const aC = centroid({type: 'Feature', geometry: {type: 'Point', coordinates: [-152, 64]}} as any);
  const dc = P([-77.04, 38.9]);
  const usO = P([-100, 40]);
  const ruO = P([172, 66]);
  const nome = P([-165.4, 64.5]), prud = P([-148.3, 70.25]), bering = P([-168.9, 65.8]);
  const gapPts: [number, number][] = [[-131.6, 55.3], [-122.75, 49.0]];
  const gapDraw = prog(sec, 4.3, 6.0);
  const gapShown = sec > 4.1 && sec < 7.4;
  // Russia -> US sale arrow (Chukotka to Alaska)
  const arrow = arcPts([177.5, 64.7], [-165.4, 64.5], 20);
  const aU = prog(sec, 14.6, 16.2);
  const arrowPath = 'M' + arrow.slice(0, Math.max(2, Math.round(arrow.length * aU))).map((p) => p.join(',')).join('L');
  const tip = arrow[arrow.length - 1], prev = arrow[arrow.length - 2];
  const ang = (Math.atan2(tip[1] - prev[1], tip[0] - prev[0]) * 180) / Math.PI;
  const alaskaFlagRU = sec < 15.6;

  return (
    <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
      <defs>
        <radialGradient id="ocean" cx="50%" cy="45%" r="80%"><stop offset="0" stopColor="#0d2238" /><stop offset="1" stopColor="#030912" /></radialGradient>
        <clipPath id="land"><path d={D.land} /></clipPath>
      </defs>
      <rect width={1080} height={1920} fill="url(#ocean)" />
      <g transform={`translate(540,960) rotate(${cam.r}) scale(${z}) translate(${-cam.x},${-cam.y})`}>
        <path d={D.graticule} fill="none" stroke="#7fa8c9" strokeOpacity={0.12} strokeWidth={1 / z} />
        <g clipPath="url(#land)">
          <rect x={-3200} y={-3200} width={6400} height={6400} fill="#1b2420" />
          <image href={staticFile('relief.jpg')} x={-2400} y={-2400} width={4800} height={4800} opacity={0.95} preserveAspectRatio="none" />
        </g>
        <path d={D.land} fill="none" stroke="#9fc4d8" strokeOpacity={0.35} strokeWidth={1.2 / z} />
        <path d={D.borders} fill="none" stroke="#c8d3da" strokeOpacity={0.4} strokeWidth={1 / z} />

        {/* Canada highlight while the gap is explained */}
        {gapShown && <path d={D.canada} fill="#ffd166" fillOpacity={0.16 * Math.min(1, gapDraw * 2)} />}

        {/* Flags, clipped to real country geometry */}
        {sec < 14.4 && <Flag id="ru-rus" region="russia" d={D.russia} flag="ru" from={11.0} to={12.2} sec={sec} origin={ruO} />}
        <Flag id="ru-ak" region="alaska" d={D.alaska} flag="ru" from={7.6} to={8.7} sec={sec} origin={aC} />
        <Flag id="us-ak" region="alaska" d={D.alaska} flag="us" from={15.2} to={16.4} sec={sec} origin={aC} />
        <Flag id="us-48" region="lower48" d={D.lower48} flag="us" from={19.5} to={21.0} sec={sec} origin={dc} />

        {/* Animated borders */}
        <Outline d={D.alaska} z={z} draw={prog(sec, 1.2, 2.6) * 1} w={2.6} />
        <Outline d={D.russia} z={z} draw={prog(sec, 0.2, 1.6)} w={2} />
        <Outline d={D.canada} z={z} draw={gapShown ? prog(sec, 3.9, 5.0) : 0} w={2} color={ACCENT} />
        <Outline d={D.lower48} z={z} draw={prog(sec, 4.4, 5.6)} w={2.2} />

        {/* Dotted line across Canada (Alaska panhandle to Washington state) */}
        {gapShown && (
          <path d={line(gapPts)} fill="none" stroke={ACCENT} strokeWidth={3.2 / z} strokeLinecap="round" strokeDasharray={`${1 / z} ${14 / z}`} strokeDashoffset={-sec * 40 / z} opacity={gapDraw} />
        )}
        {/* Sale arrow */}
        {aU > 0 && (
          <g>
            <path d={arrowPath} fill="none" stroke={ACCENT} strokeWidth={5 / z} strokeLinecap="round" strokeDasharray={`${18 / z} ${10 / z}`} strokeDashoffset={-sec * 60 / z} />
            {aU > 0.95 && <polygon points={`0,${-13 / z} ${26 / z},0 0,${13 / z}`} fill={ACCENT} transform={`translate(${tip[0]},${tip[1]}) rotate(${ang}) translate(${-26 / z},0)`} />}
          </g>
        )}
        {/* Markers */}
        <Marker p={dc} z={z} sec={sec} at={20.9} />
        <Marker p={nome} z={z} sec={sec} at={28.2} />
        <Marker p={prud} z={z} sec={sec} at={29.1} />
        <Marker p={bering} z={z} sec={sec} at={30.0} />
        {/* Final US glow pulse */}
        {sec > 34.2 && <Outline d={D.alaska} z={z} draw={1} w={3} />}
        {sec > 34.2 && <Outline d={D.lower48} z={z} draw={1} w={3} />}
      </g>
    </svg>
  );
};
