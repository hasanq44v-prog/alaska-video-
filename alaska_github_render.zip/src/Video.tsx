import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {cameraAt} from './camera';
import {MapLayer} from './MapLayer';
import {Overlay} from './Overlay';
import {Sfx} from './Sfx';

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sec = frame / fps;
  const cam = cameraAt(sec);
  return (
    <AbsoluteFill style={{background: '#02050a'}}>
      <MapLayer sec={sec} cam={cam} />
      <Overlay sec={sec} cam={cam} />
      <Sfx />
    </AbsoluteFill>
  );
};
