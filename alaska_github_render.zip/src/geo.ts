import {geoAzimuthalEqualArea, geoPath, geoGraticule10, geoCentroid, geoInterpolate} from 'd3-geo';
import {feature, merge, mesh} from 'topojson-client';
import worldTopo from 'world-atlas/countries-10m.json';
import landTopo from 'world-atlas/land-10m.json';
import statesTopo from 'us-atlas/states-10m.json';

const world: any = worldTopo;
const states: any = statesTopo;

export const BASE_SCALE = 1500;
export const projection = geoAzimuthalEqualArea().rotate([150, -60]).scale(BASE_SCALE).translate([0, 0]).clipAngle(105).precision(0.3);
export const path = geoPath(projection);

const countries: any = feature(world, world.objects.countries);
const byId = (id: string) => countries.features.find((f: any) => f.id === id);

export const russia = byId('643');
export const canada = byId('124');
export const alaska: any = (feature(states, states.objects.states) as any).features.find((f: any) => f.id === '02');
// Lower 48 = all US states except Alaska (02) and Hawaii (15)
export const lower48: any = merge(states, states.objects.states.geometries.filter((g: any) => g.id !== '02' && g.id !== '15'));

export const D = {
  land: path({type: 'FeatureCollection', features: countries.features.filter((f: any) => f.id !== '462' && f.id !== '010')} as any) as string,
  borders: path(mesh(world, world.objects.countries, (a: any, b: any) => a !== b) as any) as string,
  graticule: path(geoGraticule10()) as string,
  russia: path(russia) as string,
  canada: path(canada) as string,
  alaska: path(alaska) as string,
  lower48: path({type: 'Feature', properties: {}, geometry: lower48} as any) as string,
};
export const bounds = {
  alaska: path.bounds(alaska),
  lower48: path.bounds({type: 'Feature', properties: {}, geometry: lower48} as any),
  russia: path.bounds(russia),
};
export const P = (lonlat: [number, number]) => projection(lonlat) as [number, number];
export const line = (pts: [number, number][]) => path({type: 'LineString', coordinates: pts} as any) as string;
export const arcPts = (a: [number, number], b: [number, number], n = 24) => {
  const i = geoInterpolate(a, b);
  return Array.from({length: n + 1}, (_, k) => P(i(k / n) as [number, number]));
};
export const centroid = (f: any) => P(geoCentroid(f) as [number, number]);
