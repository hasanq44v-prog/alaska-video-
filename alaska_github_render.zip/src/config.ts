export const FPS = 30;
// Master timeline: voice.wav is 36.400 s (ffprobe) -> 1092 frames at 30 FPS.
export const AUDIO_SECONDS = 36.4;
export const DURATION_FRAMES = Math.round(AUDIO_SECONDS * FPS);
