import {Easing} from 'remotion';
import {P} from './geo';

type KF = {t: number; c: [number, number]; z: number; r: number};
// Camera keyframes, timed to the real voice-over (pauses measured with ffmpeg silencedetect).
const K: KF[] = [
  {t: 0.0, c: [-178, 63], z: 0.5, r: 0},
  {t: 2.4, c: [-168, 64], z: 0.95, r: -2},
  {t: 3.4, c: [-166, 64], z: 1.0, r: -2},
  {t: 5.6, c: [-128, 54], z: 0.46, r: 2},
  {t: 7.2, c: [-126, 53], z: 0.48, r: 2},
  {t: 8.6, c: [-151, 64], z: 1.05, r: 0},
  {t: 10.4, c: [-153, 64], z: 1.12, r: -1},
  {t: 12.0, c: [-178, 63], z: 0.62, r: 0},
  {t: 13.9, c: [-176, 63], z: 0.66, r: 0},
  {t: 15.4, c: [-160, 63], z: 0.85, r: 0},
  {t: 17.2, c: [-154, 64.5], z: 1.15, r: 0},
  {t: 19.2, c: [-152, 64], z: 1.0, r: 0},
  {t: 21.0, c: [-77, 39.5], z: 1.7, r: 0},
  {t: 22.9, c: [-77, 39], z: 1.9, r: 0},
  {t: 25.4, c: [-140, 58], z: 0.8, r: 0},
  {t: 27.0, c: [-152, 64], z: 0.95, r: 0},
  {t: 31.4, c: [-160, 66], z: 1.3, r: 0},
  {t: 33.9, c: [-150, 62], z: 0.9, r: 0},
  {t: 36.4, c: [-122, 52], z: 0.45, r: 0},
];
const ease = Easing.bezier(0.65, 0, 0.25, 1);

export const cameraAt = (sec: number) => {
  let i = 0;
  while (i < K.length - 2 && sec > K[i + 1].t) i++;
  const a = K[i], b = K[i + 1];
  const u = ease(Math.min(1, Math.max(0, (sec - a.t) / (b.t - a.t))));
  const pa = P(a.c), pb = P(b.c);
  const z = Math.exp(Math.log(a.z) + (Math.log(b.z) - Math.log(a.z)) * u);
  // slow constant drift so the shot is never frozen
  const dx = Math.sin(sec * 0.7) * 6 / z, dy = Math.cos(sec * 0.5) * 5 / z;
  return {x: pa[0] + (pb[0] - pa[0]) * u + dx, y: pa[1] + (pb[1] - pa[1]) * u + dy, z, r: a.r + (b.r - a.r) * u};
};
export type Cam = ReturnType<typeof cameraAt>;
export const toScreen = (cam: Cam, p: [number, number]) => {
  const rad = (cam.r * Math.PI) / 180;
  const dx = (p[0] - cam.x) * cam.z, dy = (p[1] - cam.y) * cam.z;
  return [540 + dx * Math.cos(rad) - dy * Math.sin(rad), 960 + dx * Math.sin(rad) + dy * Math.cos(rad)] as [number, number];
};
