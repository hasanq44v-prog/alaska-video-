import React from 'react';
import {Audio, Sequence, staticFile, interpolate, useVideoConfig} from 'remotion';

// [time in seconds, sound, volume]  — each tied to a visual event in MapLayer / camera.ts
const EVENTS: [number, string, number][] = [
  [1.9, 'whoosh', 0.55], [1.2, 'reveal', 0.35], [3.5, 'whoosh', 0.55], [4.4, 'reveal', 0.3],
  [6.9, 'whoosh', 0.6], [7.6, 'reveal', 0.45], [11.0, 'whoosh', 0.55], [11.0, 'reveal', 0.35],
  [13.9, 'whoosh', 0.5], [14.7, 'reveal', 0.35], [15.3, 'impact', 0.6], [17.1, 'impact', 0.55],
  [19.3, 'whoosh', 0.65], [19.6, 'reveal', 0.35], [20.9, 'click', 0.7], [21.0, 'impact', 0.5],
  [23.3, 'whoosh', 0.55], [25.1, 'whoosh', 0.5], [28.2, 'click', 0.7], [29.1, 'click', 0.7],
  [30.0, 'click', 0.7], [31.3, 'whoosh', 0.55], [33.8, 'whoosh', 0.6], [34.3, 'reveal', 0.4], [34.6, 'impact', 0.6],
];

export const Sfx: React.FC = () => {
  const {fps, durationInFrames} = useVideoConfig();
  return (
    <>
      <Audio src={staticFile('audio/voice.wav')} volume={1} />
      <Audio src={staticFile('audio/music.wav')} volume={(f) => 0.42 * interpolate(f, [0, 60, durationInFrames - 120, durationInFrames - 1], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
      {EVENTS.map(([t, n, v], i) => (
        <Sequence key={i} from={Math.round(t * fps)} durationInFrames={Math.round(1.4 * fps)}>
          <Audio src={staticFile(`audio/${n}.wav`)} volume={v * 0.6} />
        </Sequence>
      ))}
    </>
  );
};
