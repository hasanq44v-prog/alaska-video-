import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {FPS, DURATION_FRAMES} from './config';

export const Root: React.FC = () => (
  <Composition id="AlaskaPurchase" component={Video} durationInFrames={DURATION_FRAMES} fps={FPS} width={1080} height={1920} />
);
