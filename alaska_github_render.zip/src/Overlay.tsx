import React from 'react';
import {Easing} from 'remotion';
import {Cam, toScreen} from './camera';
import {P} from './geo';

const clamp = (v: number) => Math.min(1, Math.max(0, v));
const FONT = "'Open Sans','Helvetica Neue',Arial,sans-serif";
const inOut = (s: number, a: number, b: number) => {
  const e = Easing.bezier(0.2, 0.8, 0.2, 1);
  return e(clamp((s - a) / 0.45)) * (1 - Easing.in(Easing.quad)(clamp((s - (b - 0.35)) / 0.35)));
};

type Cap = {a: number; b: number; main: string; sub?: string};
const CAPS: Cap[] = [
  {a: 0.3, b: 6.4, main: 'WHY DID RUSSIA SELL ALASKA?'},
  {a: 7.6, b: 10.4, main: 'ALASKA · 1867', sub: 'RUSSIAN TERRITORY'},
  {a: 11.0, b: 13.9, main: 'FEAR OF WAR · NEED OF MONEY'},
  {a: 17.0, b: 19.3, main: '$7.2 MILLION', sub: 'THE PRICE OF ALASKA'},
  {a: 21.0, b: 23.0, main: 'MARCH 30, 1867', sub: 'WASHINGTON, D.C.'},
  {a: 23.5, b: 26.1, main: '“SEWARD’S FOLLY”', sub: 'A TERRIBLE DEAL?'},
  {a: 34.2, b: 36.4, main: 'ALASKA BECAME PART OF AMERICA'},
];
type GeoL = {a: number; b: number; text: string; ll: [number, number]; dy?: number; color?: string};
const GEO: GeoL[] = [
  {a: 1.0, b: 7.2, text: 'RUSSIA', ll: [168, 67]},
  {a: 1.6, b: 3.6, text: 'ALASKA', ll: [-152, 65.5]},
  {a: 4.4, b: 7.0, text: 'CANADA', ll: [-118, 58], color: '#ffd166'},
  {a: 4.8, b: 7.0, text: 'UNITED STATES', ll: [-104, 41]},
  {a: 8.0, b: 10.4, text: 'ALASKA', ll: [-152, 65.5]},
  {a: 11.4, b: 13.9, text: 'RUSSIA', ll: [168, 67]},
  {a: 21.2, b: 23.0, text: 'WASHINGTON, D.C.', ll: [-77.04, 38.9], dy: -40},
  {a: 28.4, b: 33.4, text: 'GOLD · NOME', ll: [-165.4, 64.5], dy: 40, color: '#ffd166'},
  {a: 29.3, b: 33.4, text: 'OIL · PRUDHOE BAY', ll: [-148.3, 70.25], dy: -40, color: '#ffd166'},
  {a: 30.2, b: 33.4, text: 'STRATEGIC LOCATION · BERING STRAIT', ll: [-168.9, 65.8], dy: -78, color: '#ffd166'},
];

export const Overlay: React.FC<{sec: number; cam: Cam}> = ({sec, cam}) => {
  return (
    <div style={{position: 'absolute', inset: 0, fontFamily: FONT, color: '#fff'}}>
      {/* cinematic grade */}
      <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 45%, rgba(0,0,0,0.72) 100%)'}} />
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 520, background: 'linear-gradient(to top, rgba(0,0,0,0.78), rgba(0,0,0,0))'}} />
      {GEO.map((g, i) => {
        const o = inOut(sec, g.a, g.b);
        if (o <= 0) return null;
        const [x, y] = toScreen(cam, P(g.ll));
        const px = Math.min(940, Math.max(140, x)), py = Math.min(1560, Math.max(260, y + (g.dy ?? 0)));
        return (
          <div key={i} style={{position: 'absolute', left: px, top: py, transform: 'translate(-50%,-50%)', opacity: o, whiteSpace: 'nowrap', fontWeight: 800, fontSize: 34, letterSpacing: 5, color: g.color ?? '#fff', textShadow: '0 2px 12px #000, 0 0 3px #000'}}>
            {g.text}
          </div>
        );
      })}
      {CAPS.map((c, i) => {
        const o = inOut(sec, c.a, c.b);
        if (o <= 0) return null;
        return (
          <div key={i} style={{position: 'absolute', left: 90, right: 90, top: 1390, textAlign: 'center', opacity: o, transform: `translateY(${(1 - o) * 30}px)`}}>
            <div style={{fontWeight: 800, fontSize: c.main.length > 22 ? 54 : 78, lineHeight: 1.12, letterSpacing: 3, textShadow: '0 4px 24px #000, 0 0 4px #000'}}>{c.main}</div>
            {c.sub && <div style={{marginTop: 14, fontWeight: 600, fontSize: 36, letterSpacing: 8, color: '#ffd166', textShadow: '0 2px 12px #000'}}>{c.sub}</div>}
          </div>
        );
      })}
    </div>
  );
};
