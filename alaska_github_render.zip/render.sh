#!/bin/bash
# usage: ./render.sh [out.mp4]   Optional: CHROME_PATH=/path/to/chrome CONCURRENCY=4
ARGS=(--codec=h264 --audio-codec=aac --crf=18 --concurrency=${CONCURRENCY:-4} --timeout=180000)
[ -n "$CHROME_PATH" ] && ARGS+=(--browser-executable="$CHROME_PATH")
npx remotion render src/index.ts AlaskaPurchase "${1:-out/alaska_purchase.mp4}" "${ARGS[@]}"
