# Alaska Purchase - Remotion project
1080x1920, 30 FPS, 1092 frames (= voice.wav, 36.400 s, unaltered).
1. npm install
2. ./render.sh out/alaska_purchase.mp4  (use a multi-core PC; Remotion fetches Chrome itself)
3. Preview: npx remotion studio src/index.ts
Audio: public/audio/voice.wav (original) + synthesized music/whoosh/impact/click/reveal (ffmpeg, license-free).
Map: Natural Earth 10m (world-atlas) + US Census states 10m (us-atlas); flags: flag-icons SVG. Terrain texture is PROCEDURAL, not satellite imagery.
Note: the JSON ends at 00:40 but the real audio is 36.4 s; scenes follow pauses measured in the audio.
